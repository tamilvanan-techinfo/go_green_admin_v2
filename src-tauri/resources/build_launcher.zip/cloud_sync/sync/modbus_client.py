import asyncio
import struct
import minimalmodbus
import serial
import os

from pathlib import Path
from asgiref.sync import sync_to_async

from .services import save_monitor_data
from core.models import Cycle
from core.models import DCModbusReadControl as ModbusReadControl
import traceback
import threading
import os
import time
import serial
import serial.tools.list_ports


# ==================================================
# ENVIRONMENT CONFIGURATION
# ==================================================





def _load_env():
    """
    Load .env from the backend root directory.
    """

    env_path = Path(__file__).resolve().parents[3] / ".env"

    if not env_path.exists():
        env_path = (
            Path(__file__).resolve().parent.parent.parent / ".env"
        )

    if env_path.exists():
        with open(env_path, "r", encoding="utf-8") as f:

            for line in f:
                line = line.strip()

                if line and "=" in line and not line.startswith("#"):
                    key, val = line.split("=", 1)
                    os.environ.setdefault(key.strip(), val.strip())


_load_env()
DC_ENABLED = os.environ.get("DC_ENABLED", "true").lower() in ("true", "1", "yes")


# ==================================================
# MODBUS CONFIGURATION
# ==================================================

PORT = os.environ.get("DC_COM_PORT", "COM11")

BAUDRATE = int(
    os.environ.get("DC_BAUDRATE", "19200")
)

POLL_INTERVAL = float(
    os.environ.get("DC_POLL", "1.0")
)

DC_REG_VOLTAGE = 1606
DC_REG_CURRENT = 1608
DC_REG_POWER = 1610
DC_REG_ENERGY = 1612

print(
    "[DC DEBUG] Configuration loaded | "
    f"file={__file__} | "
    f"pid={os.getpid()} | "
    f"thread={threading.current_thread().name} | "
    f"port={PORT} | "
    f"baudrate={BAUDRATE} | "
    f"poll_interval={POLL_INTERVAL}",
    flush=True,
)


def debug_com_port(port=PORT, baudrate=BAUDRATE):
    print(f"\n[COM DEBUG] Checking {port}...")
    print(f"[COM DEBUG] Backend PID: {os.getpid()}")

    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        print(
            f"[COM DEBUG] Detected: {p.device} | "
            f"Description: {p.description} | "
            f"HWID: {p.hwid}"
        )

    if not any(p.device.upper() == port.upper() for p in ports):
        print(f"[COM DEBUG] WARNING: {port} not listed by Windows.")
        return

    try:
        with serial.Serial(port, baudrate, timeout=1) as ser:
            print(f"[COM DEBUG] SUCCESS: Opened {port} @ {baudrate}.")
    except Exception as exc:
        print(
            f"[COM DEBUG] FAILED to open {port}: "
            f"{type(exc).__name__}: {exc}"
        )


# ==================================================
# DATABASE FUNCTIONS
# ==================================================

@sync_to_async(thread_sensitive=False)
def get_addresses():
    """
    Get controller numbers from the Cycle table.
    """

    return list(
        Cycle.objects.values_list(
            "controller_no",
            flat=True
        )
    )


@sync_to_async(thread_sensitive=False)
def is_read_enabled():
    """
    Check whether the backend Read Data switch is ON.
    """

    control = ModbusReadControl.get_control()

    return control.read_enabled


# ==================================================
# SERIAL PORT CONFIGURATION
# ==================================================

def create_serial_port():
    """Create a serial object without opening the COM port."""

    print(
        "[DC DEBUG] Creating serial object | "
        f"pid={os.getpid()} | "
        f"port={PORT} | "
        f"baudrate={BAUDRATE}",
        flush=True,
    )

    ser = serial.Serial(
        port=None,
        baudrate=BAUDRATE,
        bytesize=8,
        parity=serial.PARITY_NONE,
        stopbits=1,
        timeout=1.0,
    )

    ser.port = PORT

    print(
        "[DC DEBUG] Serial object created | "
        f"pid={os.getpid()} | "
        f"port={ser.port} | "
        f"is_open={ser.is_open}",
        flush=True,
    )

    return ser

# ==================================================
# CREATE MODBUS INSTRUMENT
# ==================================================
def make_instrument(addr, shared_serial):
    """
    Create a Modbus instrument that shares an existing Serial object.
    Never pass a PORT string here — minimalmodbus would open the port itself
    and orphan the handle.
    """
    inst = minimalmodbus.Instrument(
        shared_serial,          # ← Serial OBJECT, not PORT string
        addr,
        close_port_after_each_call=False,
    )
    inst.mode = minimalmodbus.MODE_RTU
    return inst


# ==================================================
# REGISTER CONVERSION
# ==================================================

def to_float(regs):
    """
    Convert two 16-bit registers into a 32-bit float.
    """

    raw = struct.pack(
        ">I",
        (regs[0] << 16) | regs[1]
    )

    return struct.unpack(">f", raw)[0]


# ==================================================
# READ MODBUS REGISTERS
# ==================================================

def read_one_sync(inst):
    """
    Blocking Modbus read.
    Runs inside a thread executor.
    """

    try:

        # Read voltage
        v_regs = inst.read_registers(
            DC_REG_VOLTAGE,
            2,
            functioncode=3
        )

        # Read current
        i_regs = inst.read_registers(
            DC_REG_CURRENT,
            2,
            functioncode=3
        )

        # Read power
        p_regs = inst.read_registers(
            DC_REG_POWER,
            2,
            functioncode=3
        )

        return {
            "voltage": round(to_float(v_regs), 2),
            "amperage": round(to_float(i_regs), 3),
            "power": round(to_float(p_regs), 3),
        }

    except Exception as e:

        print(
            f"[Modbus] Read error on instrument "
            f"{inst.address}: {e}"
        )

        return None


# ==================================================
# MODBUS POLLER
# ==================================================

class ModbusPoller:

    def __init__(self):

        self.meters = {}

        # Shared serial connection
        self.serial_port = None

        # Track switch state
        self.previous_read_enabled = None


    # --------------------------------------------------
    # CREATE / UPDATE CONTROLLERS
    # --------------------------------------------------

    async def update_meters(self):
        addresses = await get_addresses()
        try:
            addresses = [int(a) for a in addresses]
        except (ValueError, TypeError) as e:
            print(f"[Modbus] Invalid controller address: {e}")
            return

        addresses = list(set(addresses))

        if not addresses:
            if self.meters:
                print("[Modbus] No controllers found. Removing instruments.")
            self.meters = {}
            self.disconnect_comport()
            return

        # Open port FIRST. If this fails, leave self.meters empty so the
        # poll loop skips this cycle.
        if not self.connect_comport():
            return

        for addr in addresses:
            if addr not in self.meters:
                try:
                    self.meters[addr] = make_instrument(addr, self.serial_port)
                    print(f"[Modbus] Added controller: {addr}")
                except Exception as e:
                    print(f"[Modbus] Failed to create instrument for {addr}: {e}")

        current = set(addresses)
        for addr in list(self.meters.keys()):
            if addr not in current:
                print(f"[Modbus] Removing controller: {addr}")
                del self.meters[addr]

    def connect_comport(self) -> bool:
        if self.serial_port is not None and self.serial_port.is_open:
            return True

        if self.serial_port is None:
            self.serial_port = create_serial_port()

        MAX_ATTEMPTS = 5
        RETRY_DELAY_S = 0.3

        for attempt in range(1, MAX_ATTEMPTS + 1):
            try:
                print(
                    f"[DC DEBUG] Attempting to open serial port "
                    f"(try {attempt}/{MAX_ATTEMPTS}) | "
                    f"pid={os.getpid()} | port={PORT}",
                    flush=True,
                )
                self.serial_port.open()
                print(
                    f"[DC DEBUG] SERIAL OPEN SUCCESS | "
                    f"pid={os.getpid()} | port={PORT}",
                    flush=True,
                )
                return True
            except Exception as exc:
                if attempt == MAX_ATTEMPTS:
                    print(f"[DC DEBUG] Cannot open {PORT}: {exc}", flush=True)
                    debug_com_port(PORT, BAUDRATE)
                    traceback.print_exc()
                    # Discard everything: instruments hold stale refs
                    try:
                        self.serial_port.close()
                    except Exception:
                        pass
                    self.serial_port = None
                    self.meters = {}
                    return False
                time.sleep(RETRY_DELAY_S)

        return False

    def disconnect_comport(self):
        if self.serial_port is None:
            return
        try:
            if self.serial_port.is_open:
                self.serial_port.close()
                print(f"[Modbus] COM port disconnected: {PORT}")
        except Exception as e:
            print(f"[Modbus] Failed to disconnect {PORT}: {e}")

    async def poll_forever(self):
        if not DC_ENABLED:
            print("[Modbus] DC polling disabled in config. Poller not started.", flush=True)
            return
        loop = asyncio.get_running_loop()
        print(
            "[DC DEBUG] POLLER STARTED | "
            f"pid={os.getpid()} | poller_object_id={id(self)}",
            flush=True,
        )

        while True:
            try:
                enabled = await is_read_enabled()
                if enabled != self.previous_read_enabled:
                    print("[Modbus] Read Data ON. Connecting to COM port."
                        if enabled else
                        "[Modbus] Read Data OFF. Disconnecting COM port.")
                    self.previous_read_enabled = enabled

                if not enabled:
                    self.disconnect_comport()
                    await asyncio.sleep(POLL_INTERVAL)
                    continue

                await self.update_meters()          # opens port + builds instruments

                if not self.meters:
                    print("[Modbus] No controllers available.")
                    await asyncio.sleep(POLL_INTERVAL)
                    continue

                for addr, inst in list(self.meters.items()):
                    try:
                        enabled = await is_read_enabled()
                        if not enabled:
                            print("[Modbus] Switch OFF. Stopping polling cycle.")
                            self.disconnect_comport()
                            break

                        reading = await loop.run_in_executor(
                            None, read_one_sync, inst
                        )
                        if reading is None:
                            continue

                        data = {
                            "controller_no": str(addr),
                            "voltage": reading["voltage"],
                            "amperage": reading["amperage"],
                            "power": reading["power"],
                        }
                        print(f"[Modbus] Read data: {data}")
                        await save_monitor_data(data)
                    except Exception as e:
                        print(f"[Modbus] Error polling controller {addr}: {e}")

                    await asyncio.sleep(0.15)

            except asyncio.CancelledError:
                print("[Modbus] Poller cancelled. Shutting down.")
                self.disconnect_comport()
                raise
            except Exception as e:
                print(f"[Modbus] Unexpected polling error: {e}")
                self.disconnect_comport()

            await asyncio.sleep(POLL_INTERVAL)