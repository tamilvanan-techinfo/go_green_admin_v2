from django.apps import AppConfig
from pathlib import Path

from django.conf import settings
from django.core.files import File

class CoreAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core"

    def ready(self):
        import core.signals

        from django.db.models.signals import post_migrate
        # post_migrate.connect(create_default_cycles, sender=self)
        post_migrate.connect(create_default_superuser, sender=self)
        post_migrate.connect(create_app_theme, sender=self)
        post_migrate.connect(screen_lists, sender=self)
        post_migrate.connect(screen_position, sender=self)
        post_migrate.connect(create_group_participant, sender=self)
        post_migrate.connect(create_free_text, sender=self)

# def create_default_cycles(sender, **kwargs):
#     from .models import Cycle

#     for i in range(1, 13):  # 1 to 12
#         Cycle.objects.get_or_create(
#             cycle_no=f"{i:02d}",       # 01, 02, ..., 12
#             controller_no=f"CTRL-{i}"  # CTRL-1, ..., CTRL-12
#         )


def create_default_superuser(sender, **kwargs):
    from django.contrib.auth import get_user_model

    User = get_user_model()
    username = "admin"
    password = "Admin@123"

    user, created = User.objects.get_or_create(
        username=username,
        defaults={
            "is_staff": True,
            "is_superuser": True,
            "is_active": True,
        },
    )

    if created:
        user.set_password(password)
        user.save()



def create_app_theme(sender,**kwargs):
    from .models import AppTheme
    theme = AppTheme.objects.get_or_create(name="Default",is_active=True)


def screen_lists(sender, **kwargs):
    from screen_controller.models import Screen

    # Folder containing your original thumbnail images
    thumbnail_dir = Path(settings.BASE_DIR) / "thumbnails"

    screens = [
        {
            "name": "Default Screen",
            "path": "/",
            "game": "go-green",
            "is_live": True,
            "thumbnail": "01_default_screen.png",
        },
        {
            "name": "Welcome Screen",
            "path": "/welcome",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "02_welcome_screen.png",
        },
        {
            "name": "Individual Ranking Screen",
            "path": "/individual",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "03_individual_ranking.png",
        },
        {
            "name": "Group Ranking Screen",
            "path": "/group-participants",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "04_group_ranking.png",
        },
        {
            "name": "Line Graph Screen",
            "path": "/player-analysis",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "05_line_graph.png",
        },
        {
            "name": "Free Text Screen",
            "path": "/free-text",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "06_free_text.png",
        },
        {
            "name": "Participant Screen",
            "path": "/participants",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "07_participant.png",
        },
        {
            "name": "Barchart Screen",
            "path": "/live-barchart",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "08_barchart.png",
        },
        {
            "name": "Combined View",
            "path": "/combined-view",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "09_combined_view.png",
        },
        {
            "name": "Leaders Screen",
            "path": "/participant-rank",
            "game": "go-green",
            "is_live": False,
            "thumbnail": "10_leaders.png",
        },
        # FANPOWER SCREENS
        {
            "name": "Default Screen",
            "path": "/",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_default_screen.png",
        },
        {
            "name": "Individual Screen",
            "path": "/individual",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_individual_screen.png",
        },
        {
            "name": "Participant Screen",
            "path": "/participants",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_participants_screen.png",
        },
        {
            "name": "Group Ranking Screen",
            "path": "/group-participants",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_group_ranking_screen.png",
        },
        {
            "name": "Welcome Screen",
            "path": "/welcome",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_welcome_screen.png",
        },
      
        {
            "name": "Line Graph Screen",
            "path": "/player-analysis",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_line_graph_screen.png",
        },
        {
            "name": "Free Text Screen",
            "path": "/free-text",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_free_text_screen.png",
        },
        {
            "name": "Live Barchart Screen",
            "path": "/live-barchart",
            "game": "fanpower",
            "is_live": False,
            "thumbnail": "fanpower_barchart_screen.png",
        },
    ]

    for item in screens:
        screen, created = Screen.objects.get_or_create(
            path=item["path"],
            game = item["game"],
            defaults={
                "name": item["name"],
                "is_live": item["is_live"],
            },
        )

        # Set the thumbnail for new or existing screens
        if not screen.thumbnail:
            image_path = thumbnail_dir / item["thumbnail"]

            if not image_path.exists():
                print(f"Thumbnail not found: {image_path}")
                continue

            try:
                with image_path.open("rb") as image_file:
                    screen.thumbnail.save(
                        image_path.name,
                        File(image_file),
                        save=False,
                    )

                screen.save(update_fields=["thumbnail"])

                print(
                    f"Thumbnail assigned: {screen.name} "
                    f"-> {screen.thumbnail.name}"
                )

            except Exception as error:
                print(
                    f"Failed to assign thumbnail for "
                    f"{screen.name}: {error}"
                )

        if created:
            print(f"Screen created: {screen.name}")

def screen_position(sender,**kwargs):
    from screen_controller.models import ScreenPosition
    screen = ScreenPosition.objects.filter().first()
    if screen:
        pass
    else:
        screen = ScreenPosition.objects.get_or_create(
                width = 1920,
                height = 1080,
                x=1920
            )

def create_group_participant(sender, **kwargs):
    from .models import Group, ParticipentCycle

    participants = list(
        ParticipentCycle.objects.all().order_by("id")
    )

    max_participants = 3
    total_groups = 4

    if not participants:
        # No participants yet — just create empty groups 1 to 4
        for group_number in range(1, total_groups + 1):
            group_name = f"Group {group_number}"
            group, created = Group.objects.get_or_create(name=group_name)
        print("No participants found. Created Group 1 to Group 4 with no members.")
        return

    for group_number in range(1, total_groups + 1):
        group_name = f"Group {group_number}"

        group, created = Group.objects.get_or_create(
            name=group_name
        )

        index = (group_number - 1) * max_participants
        current_participants = participants[index:index + max_participants]

        # Clear existing members first
        group.members.clear()

        # Add participants (if any left for this group)
        if current_participants:
            group.members.add(*current_participants)

        print(
            f"{group_name}: "
            f"{[p.id for p in current_participants]}"
        )

        
def create_free_text(sender, **kwargs):
    from admin_panel.models import FreeText

    text = "Welcome to GoGreen Cycle Pedaling Gamification"

    FreeText.objects.create(text=text)
