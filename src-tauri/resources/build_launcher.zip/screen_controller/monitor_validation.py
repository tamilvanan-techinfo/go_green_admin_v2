from math import isfinite

from .models import MonitorLayout, Windows


def rectangles_overlap(a, b):
    """
    Edge-touching is allowed. Only positive-area intersections overlap.
    """
    return (
        a["x"] < b["x"] + b["width"]
        and a["x"] + a["width"] > b["x"]
        and a["y"] < b["y"] + b["height"]
        and a["y"] + a["height"] > b["y"]
    )


def validate_monitor_layout(monitors):
    if not isinstance(monitors, list) or not monitors:
        return False, "No monitors were reported."

    seen_ids = set()

    for monitor in monitors:
        if not isinstance(monitor, dict):
            return False, "Invalid monitor entry."

        monitor_id = monitor.get("id")
        bounds = monitor.get("bounds")

        if monitor_id is None or not isinstance(bounds, dict):
            return False, "Monitor ID or bounds are missing."

        monitor_id = str(monitor_id).strip()

        if not monitor_id or monitor_id in seen_ids:
            return False, "Monitor IDs must be unique and non-empty."

        seen_ids.add(monitor_id)

        for field in ("x", "y", "width", "height"):
            value = bounds.get(field)

            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not isfinite(value)
            ):
                return False, f"Invalid monitor {field}."

        if bounds["width"] <= 0 or bounds["height"] <= 0:
            return False, "Monitor dimensions must be positive."

    return True, None


def get_monitor_layout():
    layout = MonitorLayout.objects.filter(pk=1).first()

    if not layout or not layout.monitors:
        raise ValueError(
            "Monitor layout has not been reported by the display client yet."
        )

    valid, error = validate_monitor_layout(layout.monitors)

    if not valid:
        raise ValueError(error)

    return layout.monitors


def get_containing_monitor(rect, monitors):
    """
    Return the one monitor that completely contains this rectangle.
    """
    matches = []

    for monitor in monitors:
        bounds = monitor["bounds"]

        inside = (
            rect["x"] >= bounds["x"]
            and rect["y"] >= bounds["y"]
            and rect["x"] + rect["width"]
                <= bounds["x"] + bounds["width"]
            and rect["y"] + rect["height"]
                <= bounds["y"] + bounds["height"]
        )

        if inside:
            matches.append(monitor)

    if len(matches) != 1:
        return None

    return matches[0]


def get_effective_window_rect(position, monitors):
    """
    For normal windows, use the stored rectangle.
    For fullscreen windows, use the entire monitor rectangle.
    """
    rect = {
        "x": position.x,
        "y": position.y,
        "width": position.width,
        "height": position.height,
    }

    monitor = get_containing_monitor(rect, monitors)

    if monitor is None:
        raise ValueError(
            "The window must fit entirely inside one connected monitor."
        )

    if position.fullscreen:
        return monitor["bounds"], monitor

    return rect, monitor


def validate_window_geometry(
    x,
    y,
    width,
    height,
    fullscreen=False,
    exclude_window_id=None,
):
    """
    Validate a proposed window position against all other active windows.

    Returns:
        (True, None) on success
        (False, error_message) on failure
    """
    try:
        values = (x, y, width, height)

        if any(
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not isfinite(value)
            for value in values
        ):
            return False, "Window coordinates and dimensions must be finite numbers."

        if width <= 0 or height <= 0:
            return False, "Window width and height must be positive."

        monitors = get_monitor_layout()

        proposed_position = type(
            "ProposedPosition",
            (),
            {
                "x": int(x),
                "y": int(y),
                "width": int(width),
                "height": int(height),
                "fullscreen": bool(fullscreen),
            },
        )()

        proposed_rect, proposed_monitor = get_effective_window_rect(
            proposed_position,
            monitors,
        )

        other_windows = (
            Windows.objects
            .select_related("position")
            .filter(is_active=True)
        )

        if exclude_window_id is not None:
            other_windows = other_windows.exclude(pk=exclude_window_id)

        for other in other_windows:
            if other.position is None:
                continue

            try:
                other_rect, other_monitor = get_effective_window_rect(
                    other.position,
                    monitors,
                )
            except ValueError:
                # Do not allow new geometry while an existing active
                # window has invalid monitor placement.
                return False, (
                    f"Existing window '{other.name}' has invalid monitor "
                    "placement. Correct that window first."
                )

            if str(other_monitor["id"]) != str(proposed_monitor["id"]):
                continue

            if rectangles_overlap(proposed_rect, other_rect):
                return False, (
                    f"Window overlaps with '{other.name}' "
                    f"(window ID {other.pk}) on monitor "
                    f"{proposed_monitor['id']}."
                )

        return True, None

    except ValueError as error:
        return False, str(error)