"""
URL configuration for electricity_monitoring_be project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static

from core import web
from core import api
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', web.home, name='home'),
    path('login/', web.login_view, name='login'),
    path('dashboard/', web.dashboard, name='dashboard'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    path('cycle/register/', web.register_cycle, name='register-cycle'),
    path('participent/register/', web.register_participent, name='register-participent'),
    path('allocate/', web.allocate_cycle, name='allocate-cycle'),
    path('screens/', include('screen_controller.urls')),
    path('api-auth/', include('rest_framework.urls')),
    path('admin/', admin.site.urls),
    path('api/update-reading/', api.UpdateReadingAPIView.as_view(), name='api-update-reading'),
    path('api/get_active_screen/', api.LastScreenAPIView.as_view(), name='api-get-active-screen'),
    path('api/group/', api.GroupAPIView.as_view(), name='api-group'),
    path('api/participants-data/', api.ParticipantAPIView.as_view(), name='participants-data'),
    path("api/admin/", include("admin_panel.urls")),
    path('export/',include('excel_report.urls')),
    path('fm/',include('file_manager.urls'))

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
